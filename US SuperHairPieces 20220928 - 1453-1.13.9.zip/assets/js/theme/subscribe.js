import PageManager from './page-manager';

export default class Subscribe extends PageManager {}
